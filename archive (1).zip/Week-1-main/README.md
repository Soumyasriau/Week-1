# Week-1
AICTE Internship Project – Garbage Classification using Transfer Learning (P4) A machine learning project to classify waste into biodegradable and non-biodegradable categories using deep learning and pre-trained CNN models.
